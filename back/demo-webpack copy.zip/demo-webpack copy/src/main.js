import './scss/index.scss'
import imgs from './assets/img/a.png';
import './assets/iconfont/iconfont.scss';
import $ from 'jquery'
import './scss/swiper.scss'
import Swiper from 'swiper'

$('.iconBox').css({
  background: 'lightgreen'
})

new Swiper('.swiper-container', {})