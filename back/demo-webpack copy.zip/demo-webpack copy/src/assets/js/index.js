(() => {
  console.log('我是被引入的js')
})()


// es6代码：
let a = 1;
const hello = 'hello world';