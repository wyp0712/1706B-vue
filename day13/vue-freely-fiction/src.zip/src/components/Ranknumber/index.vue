<template>
  <div>
    <h1>ranknubber</h1>
  </div>
</template>